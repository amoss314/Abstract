package edu.umsl.abstractproject;

public abstract class Furniture {
	
	public  abstract void setCompanyName(String name);
	
	

	
	public void computePrice(int price){
		System.out.println(price);
	}
	
	
		
	}

