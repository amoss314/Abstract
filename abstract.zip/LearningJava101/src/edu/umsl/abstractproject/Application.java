package edu.umsl.abstractproject;

public class Application {

	public static void main (String[] args) {
		
		Furniture s = new Sofa();
		System.out.println("Sofa price is:");
		s.computePrice(2000);
		s.setCompanyName("Ashley Furniture");
		
		s = new CoffeTable();
		System.out.println("Coffetable price is:");
		s.computePrice(500);
		s.setCompanyName("Ashley Furniture");
	}


}
