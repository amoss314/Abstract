package edu.umsl.abstractproject;

public class CoffeTable extends Furniture {

	
	
	
	@Override
	public void computePrice(int price) {
		 super.computePrice(price);
		 
		
	}
	
	
	@Override
	public void setCompanyName(String name){
		System.out.println(name);
	}
	
}
